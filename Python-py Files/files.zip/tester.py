acks = []
for i in range(1,11):
	acks.append(0)
print(acks[11])